import React from 'react'
const Modal = () => {


  return (
<>
<h1>hello</h1>

</>
  )
}

export default Modal