

const getCategory=(state={},action)=>{
    console.log(action,"action")
    switch(action.type){
        case "GET_CATEGORY" : return{
           ...state,
           data:action.data
        }
        default:return state;
    }
}
export default getCategory;