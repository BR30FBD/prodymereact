import { combineReducers } from "redux";
import getCategory from "./getcategory";
import { todoSlide } from "./getslice";
const rootReducer=combineReducers({
   getCategory:todoSlide

})
export default rootReducer;