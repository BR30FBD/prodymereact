import { configureStore } from "@reduxjs/toolkit";
import { todoSlide } from "./reducers/getslice";

export default configureStore({
  reducer: {
    todo: todoSlide
  }
});