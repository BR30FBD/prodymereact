import React from 'react'

const Card = () => {
  return (
    <>
    
    </>
  )
}

export default Card