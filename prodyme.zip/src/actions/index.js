
// export const getCategory=()=>{
//     return {
//         type:"GET_CATEGORY",
//         payload:axios.get('https://prodymeapi.revivingindia.com/api/getCategory/').then((res)=>{
//             return res;
//         })
//     }
// }
export const getData=()=>(dispatch)=>{
    let url='https://prodymeapi.revivingindia.com/api/getCategory/';
    let result=fetch(url).then((data)=>{
        data.json().then((res)=>{
            console.log(res.data,"reduxtool")
return dispatch({
    type:"GET_CATEGORY",
    Data:res.data
})
        })
    })
}
